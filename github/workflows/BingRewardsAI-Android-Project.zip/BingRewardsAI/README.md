# Bing Rewards AI (Android)

Projeto inicial de Android Studio em Kotlin.

## O que o app faz
- Abre o Bing e o portal oficial Microsoft Rewards dentro de uma tela WebView.
- Permite anotar manualmente a pontuação exibida na conta.
- Explica como acompanhar pesquisas e atividades.

## O que não faz
- Não lê sua senha nem tenta acessar credenciais.
- Não cria pesquisas falsas, não responde automaticamente por você e não automatiza cliques para gerar pontos.
- Não lê a pontuação diretamente da conta Microsoft. O número mostrado é o que você digitar.

## Como gerar o APK
1. Extraia o ZIP.
2. Abra o Android Studio.
3. Escolha **Open** e selecione a pasta `BingRewardsAI`.
4. Aguarde a sincronização do Gradle.
5. Se o Android Studio pedir, instale o Android SDK 35 e use JDK 17.
6. Vá em **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. O APK de teste ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Requisitos
- Android Studio recente
- JDK 17
- Android SDK 35
- Internet no aparelho para abrir os sites

Este projeto é independente e não é afiliado, patrocinado ou aprovado pela Microsoft.
