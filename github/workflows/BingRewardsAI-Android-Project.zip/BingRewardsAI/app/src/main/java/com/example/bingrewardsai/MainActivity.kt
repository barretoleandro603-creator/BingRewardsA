package com.example.bingrewardsai

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("rewards_ai", MODE_PRIVATE) }
    private lateinit var pointsText: TextView
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        refreshPoints()
    }

    private fun buildScreen() {
        val bg = Color.rgb(242, 246, 251)
        val navy = Color.rgb(16, 36, 58)
        val blue = Color.rgb(22, 131, 232)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
        }
        scroll.addView(page)

        val header = TextView(this).apply {
            text = "Bing Rewards AI"
            textSize = 27f
            setTextColor(navy)
            typeface = Typeface.DEFAULT_BOLD
        }
        page.addView(header)
        page.addView(label("Seu assistente para acompanhar o Microsoft Rewards"))

        val pointsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(Color.WHITE)
        }
        val cardParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(22) }
        page.addView(pointsCard, cardParams)

        pointsCard.addView(label("PONTOS INFORMADOS POR VOCÊ").apply {
            textSize = 12f
            setTextColor(Color.DKGRAY)
        })
        pointsText = TextView(this).apply {
            textSize = 34f
            setTextColor(blue)
            typeface = Typeface.DEFAULT_BOLD
        }
        pointsCard.addView(pointsText)
        pointsCard.addView(label("O app não acessa nem altera sua pontuação da Microsoft."))
        pointsCard.addView(actionButton("Atualizar pontuação manualmente", blue) {
            askForPoints()
        })

        page.addView(sectionTitle("Começar"))
        page.addView(actionButton("Abrir Bing", blue) {
            openBrowser("https://www.bing.com/")
        })
        page.addView(actionButton("Abrir Microsoft Rewards", navy) {
            openBrowser("https://rewards.bing.com/")
        })

        page.addView(sectionTitle("Atividades"))
        page.addView(infoCard(
            "Pesquisas",
            "Faça pesquisas reais no Bing por conta própria. O aplicativo não gera pesquisas automáticas ou artificiais."
        ))
        page.addView(infoCard(
            "Quizzes e ofertas",
            "Veja as atividades disponíveis no site oficial e responda você mesmo. Confira as regras e os limites da sua conta."
        ))
        page.addView(infoCard(
            "Acompanhamento",
            "Use o botão acima para anotar a pontuação que aparece na sua conta Rewards."
        ))

        page.addView(sectionTitle("Status"))
        statusText = label("Pronto para abrir o Bing.")
        statusText.textSize = 14f
        page.addView(statusText)

        page.addView(label("Aviso: este é um assistente independente, não oficial da Microsoft. Não coleta sua senha e não automatiza ações para gerar pontos.").apply {
            textSize = 12f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(22), 0, 0)
        })

        setContentView(scroll)
    }

    private fun refreshPoints() {
        val points = prefs.getInt("points", 0)
        pointsText.text = "%,d pontos".format(points)
    }

    private fun askForPoints() {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            hint = "Ex.: 1250"
            setText(prefs.getInt("points", 0).toString())
        }
        AlertDialog.Builder(this)
            .setTitle("Atualizar pontuação")
            .setMessage("Digite o total exibido na sua conta Microsoft Rewards.")
            .setView(input)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Salvar") { _, _ ->
                val value = input.text.toString().toIntOrNull()
                if (value == null || value < 0) {
                    Toast.makeText(this, "Digite um número válido.", Toast.LENGTH_SHORT).show()
                } else {
                    prefs.edit().putInt("points", value).apply()
                    refreshPoints()
                    Toast.makeText(this, "Pontuação anotada.", Toast.LENGTH_SHORT).show()
                }
            }.show()
    }

    private fun openBrowser(url: String) {
        statusText.text = "Abrindo site oficial…"
        startActivity(Intent(this, BrowserActivity::class.java).putExtra("url", url))
    }

    private fun sectionTitle(text: String) {
        val view = TextView(this).apply {
            this.text = text
            textSize = 19f
            setTextColor(Color.rgb(16, 36, 58))
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(24), 0, dp(8))
        }
        currentPage?.addView(view)
    }

    private var currentPage: LinearLayout? = null

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(Color.rgb(76, 91, 108))
        setPadding(0, dp(6), 0, dp(6))
    }

    private fun actionButton(text: String, color: Int, action: () -> Unit) =
        Button(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            setBackgroundColor(color)
            isAllCaps = false
            textSize = 15f
            setOnClickListener { action() }
            val p = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(9) }
            layoutParams = p
        }

    private fun infoCard(title: String, body: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.WHITE)
            addView(TextView(this@MainActivity).apply {
                text = title
                textSize = 16f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(22, 55, 85))
            })
            addView(label(body))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
        }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
